from ._version import __version__
__author__ = 'Jayanti Prasad'
__email__ = 'prasad.jayanti@gmail.com'
